# Mobile-first UI

- Bottom navigation on the case list.
- Large touch targets and compact rounded cards.
- Scrollable case tabs.
- Floating action button for adding findings.
- JSON/PDF actions in the case top bar.
- Summary metrics kept visible above the tabs.
- Results show fact/assumption, confidence and timestamp at a glance.
