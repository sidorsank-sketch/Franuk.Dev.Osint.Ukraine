# Збірка APK тільки з телефона

## Варіант A — якщо в репозиторії вже є Gradle Wrapper

1. Створи GitHub repository.
2. Завантаж усі файли цього ZIP у repository.
3. Відкрий **Actions**.
4. Вибери **Build Android APK**.
5. Натисни **Run workflow**.
6. Після завершення відкрий workflow run.
7. Внизу знайди **Artifacts** → `Franuk-Dev-Osint-Ukraine-APK`.
8. Завантаж ZIP з artifact та розпакуй його — всередині буде APK.

## Варіант B — якщо GitHub показує помилку про відсутній `gradlew`

1. Відкрий **Actions**.
2. Запусти **Prepare Gradle Wrapper** один раз.
3. Workflow додасть Gradle Wrapper у repository.
4. Після цього запусти **Build Android APK**.

GitHub Actions виконує збірку на хмарному runner, тому Android SDK/Gradle локально на телефоні не потрібні.
