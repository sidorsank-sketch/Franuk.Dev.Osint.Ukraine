# Franuk.Dev.Osint.Ukraine — One-click build

## Найпростіший варіант
1. Розпакуйте проєкт.
2. Відкрийте папку в Android Studio.
3. Дочекайтеся Gradle Sync.
4. Натисніть **Run ▶** для встановлення на телефон або:
   **Build → Build APK(s)**.

## Windows
Запустіть `build_apk.bat`. Якщо у системі є налаштований Gradle/JDK,
скрипт збере debug APK і скопіює його як:

`Franuk.Dev.Osint.Ukraine-debug.apk`

## macOS / Linux
Запустіть:

`./build_apk.sh`

## Збірка в хмарі
У `.github/workflows/build-apk.yml` є GitHub Actions workflow.
Після завантаження проєкту в GitHub можна запустити workflow вручну;
готовий APK буде доступний як build artifact.

## Що всередині
- Jetpack Compose UI
- Room database
- Кейси
- Результати / Джерела / Зв'язки
- FACT / ASSUMPTION
- timestamp
- confidence
- JSON/PDF report infrastructure

Примітка: wrapper Gradle не включено, бо його `gradle-wrapper.jar` потребує
окремого бінарного файлу. Android Studio може керувати Gradle-проєктом
без ручного запуску wrapper.
