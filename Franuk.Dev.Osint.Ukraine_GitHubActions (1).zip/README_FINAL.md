# Franuk.Dev.Osint.Ukraine — Final

Готовий Android-проєкт для керування публічними OSINT-кейсами.

### Є
- Room Database
- кейси
- Результати / Джерела / Зв'язки
- Факт / Припущення
- timestamp
- confidence
- джерело + URL
- експорт JSON
- експорт PDF
- створення кейсу та додавання знахідок
- debug APK build script
- GitHub Actions workflow

### Збірка
Відкрити кореневу папку в Android Studio → Gradle Sync → Run або Build APK(s).

Проєкт не виконує прихованого стеження, обходу авторизації чи отримання приватних даних.
