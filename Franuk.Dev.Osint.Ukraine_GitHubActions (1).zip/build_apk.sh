#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
echo "=========================================="
echo " Franuk.Dev.Osint.Ukraine APK Builder"
echo "=========================================="

if [ -x "./gradlew" ]; then
  ./gradlew :app:assembleDebug
elif command -v gradle >/dev/null 2>&1; then
  gradle :app:assembleDebug
else
  echo "ERROR: Gradle wrapper/Gradle not found."
  echo "Open the project in Android Studio and run Build > Make Project,"
  echo "or install/configure Gradle."
  exit 1
fi

APK="app/build/outputs/apk/debug/app-debug.apk"
if [ -f "$APK" ]; then
  cp "$APK" "Franuk.Dev.Osint.Ukraine-debug.apk"
  echo "SUCCESS: $(pwd)/Franuk.Dev.Osint.Ukraine-debug.apk"
else
  echo "Build finished without the expected APK."
  exit 1
fi
