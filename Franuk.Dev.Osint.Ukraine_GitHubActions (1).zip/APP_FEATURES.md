# Franuk.Dev.Osint.Ukraine — App features

## UI
- Clean Material 3 interface
- Case list and case detail
- Summary metrics
- Results / Sources / Connections tabs
- Fact vs assumption labels
- Timestamp and confidence on each finding

## Data
- Room database
- Cases
- Findings
- Public source + URL fields

## Reports
- JSON export with report metadata and summary
- PDF export with case, findings, timestamps, confidence and source list

## Scope
The app is designed for public-information research and user-supplied data.
It does not implement covert tracking, bypassing authorization, or retrieval of private data.
