# Franuk.Dev.Osint.Ukraine

Android/Jetpack Compose MVP for public-data OSINT case management.

Included:
- Room case database
- Results / Sources / Connections
- FACT vs ASSUMPTION separation
- timestamp + confidence fields
- JSON/PDF export architecture
- public-source workflow only

Open the project in Android Studio and let Gradle sync.
