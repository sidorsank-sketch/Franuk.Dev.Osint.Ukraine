@echo off
cd /d "%~dp0"
echo Building Franuk.Dev.Osint.Ukraine...
if exist gradlew.bat (
  call gradlew.bat :app:assembleDebug
) else (
  where gradle >nul 2>nul
  if errorlevel 1 (
    echo Gradle not found. Open this project in Android Studio first.
    pause
    exit /b 1
  )
  gradle :app:assembleDebug
)
if exist app\build\outputs\apk\debug\app-debug.apk (
  copy /Y app\build\outputs\apk\debug\app-debug.apk Franuk.Dev.Osint.Ukraine-debug.apk >nul
  echo APK ready: %cd%\Franuk.Dev.Osint.Ukraine-debug.apk
) else (
  echo APK was not produced.
)
pause
