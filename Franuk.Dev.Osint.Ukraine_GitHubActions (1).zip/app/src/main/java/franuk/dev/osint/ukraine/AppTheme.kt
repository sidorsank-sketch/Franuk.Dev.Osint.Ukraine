
package franuk.dev.osint.ukraine

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Navy = Color(0xFF14213D)
private val Blue = Color(0xFF2563EB)
private val Surface = Color(0xFFF7F8FA)

private val LightColors = lightColorScheme(
    primary = Blue,
    onPrimary = Color.White,
    secondary = Navy,
    background = Surface,
    surface = Color.White
)

@Composable
fun OsintTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = LightColors, content = content)
}
