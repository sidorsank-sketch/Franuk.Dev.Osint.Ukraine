package franuk.dev.osint.ukraine

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "cases")
data class CaseEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val query: String,
    val type: String,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "findings")
data class FindingEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val caseId: Long,
    val title: String,
    val value: String,
    val source: String,
    val url: String = "",
    val kind: String = "FACT",
    val confidence: Int = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val tags: String = ""
)

@Dao
interface CaseDao {
    @Query("SELECT * FROM cases ORDER BY updatedAt DESC")
    fun observeAll(): Flow<List<CaseEntity>>
    @Query("SELECT * FROM cases WHERE id = :id")
    suspend fun get(id: Long): CaseEntity?
    @Insert suspend fun insert(c: CaseEntity): Long
}

@Dao
interface FindingDao {
    @Query("SELECT * FROM findings WHERE caseId = :caseId ORDER BY timestamp DESC")
    fun observeForCase(caseId: Long): Flow<List<FindingEntity>>
    @Insert suspend fun insert(f: FindingEntity): Long
}

@Database(entities = [CaseEntity::class, FindingEntity::class], version = 1)
abstract class OsintDatabase : RoomDatabase() {
    abstract fun caseDao(): CaseDao
    abstract fun findingDao(): FindingDao
    companion object {
        @Volatile private var INSTANCE: OsintDatabase? = null
        fun get(context: Context): OsintDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext, OsintDatabase::class.java, "osint.db"
                ).build().also { INSTANCE = it }
            }
    }
}
