package franuk.dev.osint.ukraine

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class MainVm(app: android.app.Application) : AndroidViewModel(app) {
    private val db = OsintDatabase.get(app)
    val cases = db.caseDao().observeAll()
    var selectedId by mutableStateOf<Long?>(null)
        private set
    val findings: StateFlow<List<FindingEntity>>
        get() = selectedId?.let { id ->
            db.findingDao().observeForCase(id)
                .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
        } ?: MutableStateFlow(emptyList())

    fun select(id: Long) { selectedId = id }
    fun back() { selectedId = null }
    fun createCase(title:String, query:String)=viewModelScope.launch {
        selectedId=db.caseDao().insert(CaseEntity(title=title,query=query,type="PUBLIC_WEB"))
    }
    fun addFinding(t:String,v:String,s:String,u:String,k:String,c:Int)=viewModelScope.launch {
        selectedId?.let { db.findingDao().insert(FindingEntity(
            caseId=it,title=t,value=v,source=s,url=u,kind=k,confidence=c.coerceIn(0,100)
        )) }
    }
}

class MainActivity : ComponentActivity() {
    private var pendingCase: CaseEntity? = null
    private var pendingFindings: List<FindingEntity> = emptyList()

    private val createJson = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri -> uri?.let { exportJson(it) } }

    private val createPdf = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri -> uri?.let { exportPdf(it) } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { OsintTheme { App() } }
    }

    private fun exportJson(uri: Uri) {
        val c=pendingCase ?: return
        contentResolver.openOutputStream(uri)?.use {
            it.write(ReportExport.json(c,pendingFindings).toByteArray(Charsets.UTF_8))
        }
    }
    private fun exportPdf(uri: Uri) {
        val c=pendingCase ?: return
        contentResolver.openOutputStream(uri)?.use {
            ReportExport.pdf(this,c,pendingFindings,it)
        }
    }

    @Composable
    fun App(vm:MainVm=viewModel()) {
        val cases by vm.cases.collectAsState(initial=emptyList())
        val findings by vm.findings.collectAsState()
        var section by remember { mutableIntStateOf(0) }
        var showCreate by remember { mutableStateOf(false) }
        var showAdd by remember { mutableStateOf(false) }

        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                if(vm.selectedId==null) "OSINT Ukraine" else "Кейс",
                                fontWeight=FontWeight.Bold
                            )
                            if(vm.selectedId==null)
                                Text("Публічні джерела",style=MaterialTheme.typography.labelSmall)
                        }
                    },
                    navigationIcon = {
                        if(vm.selectedId!=null)
                            IconButton({vm.back();section=0}) {
                                Icon(Icons.Default.ArrowBack,"Назад")
                            }
                    },
                    actions = {
                        if(vm.selectedId!=null) {
                            val c=cases.firstOrNull{it.id==vm.selectedId}
                            if(c!=null) {
                                IconButton({pendingCase=c;pendingFindings=findings;createJson.launch("case_${c.id}.json")}) {
                                    Icon(Icons.Default.Description,"JSON")
                                }
                                IconButton({pendingCase=c;pendingFindings=findings;createPdf.launch("case_${c.id}.pdf")}) {
                                    Icon(Icons.Default.PictureAsPdf,"PDF")
                                }
                            }
                        }
                    }
                )
            },
            floatingActionButton = {
                if(vm.selectedId!=null) {
                    FloatingActionButton({showAdd=true}) {
                        Icon(Icons.Default.Add,"Додати")
                    }
                }
            },
            bottomBar = {
                if(vm.selectedId==null) {
                    NavigationBar {
                        NavigationBarItem(
                            selected=true,onClick={},icon={Icon(Icons.Default.Folder,"Кейси")},
                            label={Text("Кейси")}
                        )
                        NavigationBarItem(
                            selected=false,onClick={showCreate=true},icon={Icon(Icons.Default.Add,"Новий")},
                            label={Text("Новий")}
                        )
                    }
                }
            }
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                if(vm.selectedId==null) CaseList(cases,{vm.select(it)})
                else CaseDetail(cases,findings,section,{section=it})
            }
        }

        if(showCreate) CreateDialog({showCreate=false}){t,q->vm.createCase(t,q);showCreate=false}
        if(showAdd) AddDialog({showAdd=false}){t,v,s,u,k,c->vm.addFinding(t,v,s,u,k,c);showAdd=false}
    }

    @Composable
    fun CaseList(cases:List<CaseEntity>,open:(Long)->Unit) {
        Column(Modifier.fillMaxSize().padding(horizontal=14.dp)) {
            Spacer(Modifier.height(8.dp))
            Text("Твої кейси",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold)
            Text("${cases.size} збережених кейсів",style=MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(12.dp))
            if(cases.isEmpty()) {
                Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(20.dp)) {
                        Text("Перший кейс",style=MaterialTheme.typography.titleLarge)
                        Spacer(Modifier.height(6.dp))
                        Text("Створи кейс і додавай до нього публічні знахідки.")
                    }
                }
            } else LazyColumn(
                verticalArrangement=Arrangement.spacedBy(9.dp),
                contentPadding=PaddingValues(bottom=90.dp)
            ) {
                items(cases,key={it.id}){c->
                    Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(18.dp),onClick={open(c.id)}) {
                        Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically) {
                            Icon(Icons.Default.Folder,"")
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(c.title,fontWeight=FontWeight.SemiBold)
                                Text(c.query.ifBlank{"Без запиту"},style=MaterialTheme.typography.bodySmall)
                            }
                            Icon(Icons.Default.ChevronRight,"")
                        }
                    }
                }
            }
        }
    }

    @Composable
    fun CaseDetail(cases:List<CaseEntity>,fs:List<FindingEntity>,section:Int,setSection:(Int)->Unit) {
        val c=cases.firstOrNull{it.id==viewModel<MainVm>().selectedId} ?: return
        Column(Modifier.fillMaxSize()) {
            Column(Modifier.padding(horizontal=14.dp)) {
                Spacer(Modifier.height(4.dp))
                Text(c.title,style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)
                Text(c.query.ifBlank{"Без запиту"},style=MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(10.dp))
                SummaryCard(fs)
            }
            ScrollableTabRow(selectedTabIndex=section,edgePadding=14.dp) {
                listOf("Результати","Джерела","Зв'язки").forEachIndexed{i,t->
                    Tab(section==i,{setSection(i)},text={Text(t)})
                }
            }
            Box(Modifier.fillMaxSize().padding(horizontal=14.dp)) {
                when(section){0->Results(fs);1->Sources(fs);2->Connections(fs)}
            }
        }
    }

    @Composable fun SummaryCard(fs:List<FindingEntity>) {
        val avg=if(fs.isEmpty())0 else fs.map{it.confidence}.average().toInt()
        Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(18.dp)) {
            Row(Modifier.padding(14.dp).fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
                Metric("Знахідки","${fs.size}")
                Metric("Факти","${fs.count{it.kind=="FACT"}}")
                Metric("Гіпотези","${fs.count{it.kind=="ASSUMPTION"}}")
                Metric("Confidence","$avg%")
            }
        }
    }
    @Composable fun Metric(label:String,value:String) {
        Column(horizontalAlignment=Alignment.CenterHorizontally) {
            Text(value,fontWeight=FontWeight.Bold,style=MaterialTheme.typography.titleMedium)
            Text(label,style=MaterialTheme.typography.labelSmall)
        }
    }

    @Composable fun Results(fs:List<FindingEntity>) {
        if(fs.isEmpty()){EmptyState("Знахідок ще немає");return}
        LazyColumn(
            verticalArrangement=Arrangement.spacedBy(8.dp),
            contentPadding=PaddingValues(top=10.dp,bottom=100.dp)
        ){
            items(fs,key={it.id}){f->FindingCard(f)}
        }
    }

    @Composable fun FindingCard(f:FindingEntity) {
        val date=SimpleDateFormat("dd.MM.yyyy HH:mm",Locale.getDefault()).format(Date(f.timestamp))
        Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(16.dp)) {
            Column(Modifier.padding(14.dp)) {
                Row(verticalAlignment=Alignment.CenterVertically) {
                    AssistChip(
                        onClick={},label={Text(if(f.kind=="FACT")"ФАКТ" else "ПРИПУЩЕННЯ")}
                    )
                    Spacer(Modifier.weight(1f))
                    Text("${f.confidence}%",fontWeight=FontWeight.Bold)
                }
                Spacer(Modifier.height(7.dp))
                Text(f.title,style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.SemiBold)
                if(f.value.isNotBlank()){Spacer(Modifier.height(3.dp));Text(f.value)}
                Spacer(Modifier.height(7.dp))
                Text("Джерело: ${f.source.ifBlank{"—"}}",style=MaterialTheme.typography.bodySmall)
                Text(date,style=MaterialTheme.typography.labelSmall)
            }
        }
    }

    @Composable fun Sources(fs:List<FindingEntity>) {
        val groups=fs.filter{it.source.isNotBlank()}.groupBy{it.source}
        if(groups.isEmpty()){EmptyState("Джерел ще немає");return}
        LazyColumn(
            verticalArrangement=Arrangement.spacedBy(8.dp),
            contentPadding=PaddingValues(top=10.dp,bottom=100.dp)
        ){
            items(groups.toList()){(src,list)->
                Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(16.dp)){
                    Column(Modifier.padding(14.dp)){
                        Text(src,fontWeight=FontWeight.SemiBold)
                        Text("${list.size} знахідок",style=MaterialTheme.typography.bodySmall)
                        list.map{it.url}.filter{it.isNotBlank()}.distinct().forEach{
                            Text(it,style=MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }

    @Composable fun Connections(fs:List<FindingEntity>) {
        if(fs.isEmpty()){EmptyState("Зв'язків ще немає");return}
        LazyColumn(
            verticalArrangement=Arrangement.spacedBy(8.dp),
            contentPadding=PaddingValues(top=10.dp,bottom=100.dp)
        ){
            item{
                Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(16.dp)){
                    Column(Modifier.padding(14.dp)){
                        Text("Схема кейсу",fontWeight=FontWeight.Bold)
                        Text("Кейс → джерело → знахідка",style=MaterialTheme.typography.bodySmall)
                    }
                }
            }
            items(fs){f->
                Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(16.dp)){
                    Column(Modifier.padding(12.dp)){
                        Text(f.source.ifBlank{"Джерело не вказано"},fontWeight=FontWeight.SemiBold)
                        Text("↓")
                        Text(f.title)
                        Text("confidence ${f.confidence}%",style=MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
    }

    @Composable fun EmptyState(text:String) {
        Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center) {
            Text(text,style=MaterialTheme.typography.bodyLarge)
        }
    }

    @Composable fun CreateDialog(close:()->Unit,create:(String,String)->Unit){
        var t by remember{mutableStateOf("")};var q by remember{mutableStateOf("")}
        AlertDialog(onDismissRequest=close,title={Text("Новий кейс")},text={
            Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
                OutlinedTextField(t,{t=it},label={Text("Назва")},singleLine=true)
                OutlinedTextField(q,{q=it},label={Text("Запит")},singleLine=true)
            }
        },confirmButton={Button({if(t.isNotBlank())create(t,q)}){Text("Створити")}},
        dismissButton={TextButton(close){Text("Скасувати")}})
    }

    @Composable fun AddDialog(close:()->Unit,add:(String,String,String,String,String,Int)->Unit){
        var t by remember{mutableStateOf("")};var v by remember{mutableStateOf("")}
        var s by remember{mutableStateOf("")};var u by remember{mutableStateOf("")}
        var c by remember{mutableStateOf("50")};var k by remember{mutableStateOf("FACT")}
        AlertDialog(onDismissRequest=close,title={Text("Нова знахідка")},text={
            Column(verticalArrangement=Arrangement.spacedBy(6.dp)){
                OutlinedTextField(t,{t=it},label={Text("Назва")},singleLine=true)
                OutlinedTextField(v,{v=it},label={Text("Значення")},minLines=2)
                OutlinedTextField(s,{s=it},label={Text("Джерело")},singleLine=true)
                OutlinedTextField(u,{u=it},label={Text("URL")},singleLine=true)
                Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){
                    FilterChip(k=="FACT",{k="FACT"},label={Text("Факт")})
                    FilterChip(k=="ASSUMPTION",{k="ASSUMPTION"},label={Text("Припущення")})
                }
                OutlinedTextField(c,{c=it.filter(Char::isDigit).take(3)},label={Text("Confidence 0–100")},singleLine=true)
            }
        },confirmButton={Button({if(t.isNotBlank())add(t,v,s,u,k,c.toIntOrNull()?.coerceIn(0,100)?:0)}){Text("Зберегти")}},
        dismissButton={TextButton(close){Text("Скасувати")}})
    }
}
