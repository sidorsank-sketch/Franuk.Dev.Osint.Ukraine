package franuk.dev.osint.ukraine

import android.content.Context
import android.graphics.*
import android.graphics.pdf.PdfDocument
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

object ReportExport {
    private val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)

    fun json(case: CaseEntity, findings: List<FindingEntity>): String {
        val root = JSONObject()
        root.put("report", JSONObject().apply {
            put("app", "Franuk.Dev.Osint.Ukraine")
            put("schemaVersion", "1.0")
            put("exportedAt", fmt.format(Date()))
        })
        root.put("case", JSONObject().apply {
            put("id", case.id); put("title", case.title)
            put("query", case.query); put("type", case.type)
            put("createdAt", fmt.format(Date(case.createdAt)))
            put("updatedAt", fmt.format(Date(case.updatedAt)))
        })
        val arr = JSONArray()
        findings.forEach { f ->
            arr.put(JSONObject().apply {
                put("id", f.id); put("title", f.title); put("value", f.value)
                put("kind", f.kind); put("confidence", f.confidence)
                put("source", f.source); put("url", f.url)
                put("timestamp", fmt.format(Date(f.timestamp)))
                put("tags", f.tags.split(",").filter { it.isNotBlank() })
            })
        }
        root.put("findings", arr)
        root.put("summary", JSONObject().apply {
            put("resultsCount", findings.size)
            put("factsCount", findings.count { it.kind == "FACT" })
            put("assumptionsCount", findings.count { it.kind == "ASSUMPTION" })
            put("sourcesCount", findings.map { it.source }.distinct().size)
        })
        return root.toString(2)
    }

    fun pdf(context: Context, case: CaseEntity, findings: List<FindingEntity>, output: java.io.OutputStream) {
        val doc = PdfDocument()
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.create("sans", Typeface.NORMAL); textSize = 11f }
        val bold = Paint(paint).apply { typeface = Typeface.create("sans", Typeface.BOLD); textSize = 14f }
        var pageNo = 1
        var page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, pageNo).create())
        var canvas = page.canvas
        var y = 42f
        fun line(text: String, p: Paint = paint) {
            if (y > 805) {
                doc.finishPage(page); pageNo++
                page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, pageNo).create())
                canvas = page.canvas; y = 42f
            }
            canvas.drawText(text.take(92), 36f, y, p); y += 18f
        }
        line("OSINT CASE REPORT", Paint(bold).apply { textSize = 20f })
        line("Franuk.Dev.Osint.Ukraine")
        line("Generated: ${fmt.format(Date())}")
        y += 10
        line("CASE: ${case.title}", bold)
        line("Query: ${case.query}")
        line("Type: ${case.type}")
        line("Results: ${findings.size} | Facts: ${findings.count { it.kind=="FACT" }} | Assumptions: ${findings.count { it.kind=="ASSUMPTION" }}")
        y += 12
        line("FINDINGS", bold)
        findings.forEachIndexed { i, f ->
            line("${i+1}. [${f.kind}] ${f.title}", bold)
            line("Value: ${f.value}")
            line("Source: ${f.source}")
            if (f.url.isNotBlank()) line("URL: ${f.url}")
            line("Timestamp: ${fmt.format(Date(f.timestamp))} | Confidence: ${f.confidence}%")
            if (f.tags.isNotBlank()) line("Tags: ${f.tags}")
            y += 6
        }
        y += 8
        line("SOURCES", bold)
        findings.groupBy { it.source }.forEach { (src, list) ->
            line("$src — ${list.size} finding(s)")
            list.map { it.url }.filter { it.isNotBlank() }.distinct().forEach { line("  $it") }
        }
        doc.finishPage(page)
        doc.writeTo(output)
        doc.close()
    }
}
