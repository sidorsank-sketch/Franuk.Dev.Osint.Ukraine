# Franuk.Dev.Osint.Ukraine — Phone Build

Цей пакет підготовлений для сценарію **тільки смартфон + GitHub**.

### Що робить workflow

- запускає Linux runner GitHub;
- встановлює JDK 17;
- налаштовує Gradle;
- збирає `:app:assembleDebug`;
- перейменовує APK;
- завантажує готовий APK як GitHub Actions artifact.

Потрібен лише GitHub-репозиторій і доступ до Actions.

> Debug APK призначений для встановлення/тестування. Для публічного релізу потрібне окреме підписування release APK.
